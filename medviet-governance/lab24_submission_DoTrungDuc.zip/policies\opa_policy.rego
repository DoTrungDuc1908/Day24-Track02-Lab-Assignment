package medviet.data_access

import future.keywords.if
import future.keywords.in

# Default: deny all
default allow := false

# Main decision: allow if allowed by rules and not explicitly denied
allow if {
    allow_rules
    not deny
}

# Admin được phép tất cả
allow_rules if {
    input.user.role == "admin"
}

# ML Engineer được đọc training data và model artifacts
allow_rules if {
    input.user.role == "ml_engineer"
    input.resource in {"training_data", "model_artifacts"}
    input.action in {"read", "write"}
}

# TODO: ML Engineer KHÔNG được delete production data
deny if {
    input.user.role == "ml_engineer"
    input.resource == "production_data"
    input.action == "delete"
}

# TODO: Data Analyst chỉ được đọc aggregated metrics và viết reports
allow_rules if {
    input.user.role == "data_analyst"
    input.resource == "aggregated_metrics"
    input.action == "read"
}
allow_rules if {
    input.user.role == "data_analyst"
    input.resource == "reports"
    input.action == "write"
}

# TODO: Intern chỉ được access sandbox
allow_rules if {
    input.user.role == "intern"
    input.resource == "sandbox_data"
    input.action in {"read", "write"}
}

# Rule: không ai được export restricted data ra ngoài VN servers
deny if {
    input.data_classification == "restricted"
    input.destination_country != "VN"
}
